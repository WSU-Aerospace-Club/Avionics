/** @file
 *	@brief MAVLink comm protocol.
 *	@see http://pixhawk.ethz.ch/software/mavlink
 *	 Generated on Monday, October 25 2010, 17:38 UTC
 */
#ifndef MAVLINK_H
#define MAVLINK_H

#include "ualberta.h"

#endif
